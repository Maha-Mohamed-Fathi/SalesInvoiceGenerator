package com.company.controller;

import com.company.model.invoiceHeader;
import com.company.model.invoiceLine;

import java.io.BufferedReader;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.List;

public class fileOperations {
    public static List<invoiceHeader> readInvoiceHeadersFromCSV(String fileName) {
        List<invoiceHeader> invoiceHeaders = new ArrayList<>();
        Path pathToFile = Paths.get(fileName);
        try (BufferedReader bufferedReader = Files.newBufferedReader(pathToFile)) {
            String line = bufferedReader.readLine();
            while (line != null) {
                String[] attributes = line.split(",");
                invoiceHeader invoiceHeader = createInvoiceHeader(attributes);
                invoiceHeaders.add(invoiceHeader);
                line = bufferedReader.readLine();
            }
        } catch (IOException ioe) {
            ioe.printStackTrace();
        }
        return invoiceHeaders;
    }
    private static invoiceHeader createInvoiceHeader(String[] metadata) {
        invoiceHeader invLine = new invoiceHeader();
        invLine.setInvoiceNumber(Integer.parseInt(metadata[0])) ;
        invLine.setInvoiceDate(metadata[1]);
        invLine.setCustomerName((metadata[2]));
        return new invoiceHeader(invLine.getInvoiceNumber(),invLine.getInvoiceDate(),invLine.getCustomerName());
    }

    public static List<invoiceLine> readInvoiceLinesFromCSV(String fileName) {
        List<invoiceLine> invoiceLines = new ArrayList<>();
        Path pathToFile = Paths.get(fileName);
        try (BufferedReader bufferedReader = Files.newBufferedReader(pathToFile)) {
            String line = bufferedReader.readLine();
            while (line != null) {
                String[] attributes = line.split(",");
                invoiceLine invoiceLine = createInvoiceLine(attributes);
                invoiceLines.add(invoiceLine);
                line = bufferedReader.readLine();
            }
        } catch (IOException ioe) {
            ioe.printStackTrace();
        }
        return invoiceLines;
    }
    private static invoiceLine createInvoiceLine(String[] metadata) {
        invoiceLine invLine = new invoiceLine();
        invLine.setInvoiceNumber(Integer.parseInt(metadata[0])) ;
        invLine.setItemName(metadata[1]);
        invLine.setItemPrice(Double.parseDouble(metadata[2]));
        invLine.setCount(Integer.parseInt(metadata[3]));
        return new invoiceLine(invLine.getInvoiceNumber(),invLine.getItemName(),invLine.getItemPrice(),invLine.getCount());

    }

}
