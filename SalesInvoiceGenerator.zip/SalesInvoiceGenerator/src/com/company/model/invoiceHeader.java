package com.company.model;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class invoiceHeader {

    private static int invoiceNumber;
    private Date invoiceDate;
    private String customerName;
    private ArrayList<invoiceLine> invoiceLineArray;

    public invoiceHeader(){
    }
    public invoiceHeader(int invoiceNumber,String customerName, Date invoiceDate){
        this.invoiceDate = invoiceDate;
        this.invoiceNumber = invoiceNumber;
        this.customerName= customerName;
        this.invoiceLineArray = new ArrayList<invoiceLine>();
    }

    public int getInvoiceNumber() {
        return invoiceNumber;
    }

    public Date getInvoiceDate() {
        return invoiceDate;
    }

    public String getCustomerName() {
        return customerName;
    }

    public List<invoiceLine> getInvoiceLineArray() {
        return invoiceLineArray;
    }

    public void setInvoiceNumber(int invoiceNumber) {
        this.invoiceNumber = invoiceNumber;
    }

    public void setCustomerName(String customerName) {
        this.customerName = customerName;
    }

    public void setInvoiceLineArray(List<invoiceLine> invoiceLineArray) {
        if (invoiceLineArray == null)
            invoiceLineArray = new ArrayList<invoiceLine>();
        this.invoiceLineArray = (ArrayList<invoiceLine>) invoiceLineArray;
    }

    @Override
    public String toString() {
        return "InvoiceHeader{" + "invoiceNumber=" + invoiceNumber + ", customerName=" + customerName + ", invoiceDate=" + invoiceDate + '}';
    }
}
