package com.company.model;

public class invoiceLine {

    private  int invoiceNumber;
    private String itemName;
    private Double itemPrice;
    private int count;

    public invoiceLine(){
    }

    public invoiceLine(int invoiceNumber,String itemName, Double itemPrice, int count){

        this.invoiceNumber = invoiceNumber;
        this.itemName = itemName;
        this.itemPrice= itemPrice;
        this.count = count;
    }


    public String getItemName() { return itemName; }

    public Double getItemPrice() {
        return itemPrice;
    }

    public int getCount() {
        return count;
    }

    public int getInvoiceNumber() { return invoiceNumber; }

    public void setInvoiceNumber(int invoiceNumber) { this.invoiceNumber = invoiceNumber; }

    public void setItemName(String itemName) { this.itemName = itemName; }

    public void setItemPrice(Double itemPrice) {
        this.itemPrice = itemPrice;
    }

    public void setCount(int count) {
        this.count = count;
    }

    @Override
    public String toString() {
        return  itemName + ", " + itemPrice + ", " + count;
    }
}
