package com.company;

import com.company.controller.fileOperations;
import com.company.model.invoiceHeader;
import com.company.model.invoiceLine;

import java.util.List;

public class Main {

    public static void main(String[] args) {

        fileOperations f = new fileOperations();
        List<invoiceLine> invoiceLineArray = f.readInvoiceLinesFromCSV("resources/InvoiceLine.csv");
        List<invoiceHeader> invoiceHeaderArray = f.readInvoiceHeadersFromCSV("resources/InvoiceHeader.csv");

        for (int i = 0; i<invoiceHeaderArray.size();i++)
        {
            System.out.println(invoiceHeaderArray.get(i));
            for(int j = 0; j<invoiceLineArray.size();j++)
            {
                if (invoiceLineArray.get(j).getInvoiceNumber()==invoiceHeaderArray.get(i).getInvoiceNumber())
                {
                    System.out.println(invoiceLineArray.get(j));
                }
            }
            System.out.println("}");
        }
    }
}